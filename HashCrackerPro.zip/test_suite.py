# test_suite.py - Complete test suite
import hashlib
import os
import time

def run_test_suite():
    print("🚀 HASHCRACKER PRO - COMPLETE TEST SUITE")
    print("=" * 50)
    
    # Test hashes with known passwords
    test_cases = [
        ("5f4dcc3b5aa765d61d8327deb882cf99", "password", "MD5"),
        ("d8578edf8458ce06fbc5bb76a58c5ca4", "qwerty", "MD5"),
        ("7c6a180b36896a0a8c02787eeafb0e4c", "password1", "MD5"),
        ("6c569aabbf7775ef8fc570e228c16b98", "letmein", "MD5"),
        ("5baa61e4c9b93f3f0682250b6cf8331b7ee68fd8", "password", "SHA1"),
    ]
    
    # Create test wordlist
    wordlist_content = "\n".join([case[1] for case in test_cases])
    with open("test_wordlist.txt", "w") as f:
        f.write(wordlist_content)
    
    print("📝 Created test wordlist: test_wordlist.txt")
    
    # Test each algorithm
    print("\n🔍 TESTING HASH ALGORITHMS:")
    for target_hash, password, algo_name in test_cases:
        computed = hashlib.md5(password.encode()).hexdigest() if "MD5" in algo_name else hashlib.sha1(password.encode()).hexdigest()
        status = "✅ PASS" if computed == target_hash else "❌ FAIL"
        print(f"  {algo_name:6} | {password:12} -> {status}")
    
    # Test performance
    print("\n⚡ PERFORMANCE TEST:")
    test_passwords = ["test" + str(i) for i in range(1000)]
    start_time = time.time()
    
    for pwd in test_passwords:
        hashlib.md5(pwd.encode()).hexdigest()
    
    elapsed = time.time() - start_time
    speed = len(test_passwords) / elapsed
    print(f"  Hashed {len(test_passwords)} passwords in {elapsed:.2f}s")
    print(f"  Speed: {speed:.0f} hashes/second")
    
    print("\n🎉 TEST SUITE COMPLETED SUCCESSFULLY!")
    print("Next: Try the advanced features with your own hashes!")

if __name__ == "__main__":
    run_test_suite()