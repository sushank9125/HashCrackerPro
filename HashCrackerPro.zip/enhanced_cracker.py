# enhanced_cracker.py - Improved version with better error handling
import hashlib
import multiprocessing as mp
from concurrent.futures import ProcessPoolExecutor
import time
import os
import argparse
from datetime import datetime

class EnhancedHashCracker:
    def __init__(self, max_workers=None):
        self.max_workers = max_workers or mp.cpu_count()
        self.results = []
        self.start_time = None
    
    def display_banner(self):
        banner = r"""
        ╔═══════════════════════════════════════════════╗
        ║              HASHCRACKER PRO                  ║
        ║        Parallel Password Auditing System      ║
        ║                                               ║
        ║           [Enhanced Edition]                  ║
        ╚═══════════════════════════════════════════════╝
        """
        print(banner)
    
    def clean_hash(self, hash_string):
        """Clean hash string from BOM and other artifacts"""
        # Remove BOM and other non-hex characters
        cleaned = ''.join(c for c in hash_string if c in '0123456789abcdefABCDEF')
        if len(cleaned) != len(hash_string.strip()):
            print(f"[!] Cleaned hash: '{hash_string}' -> '{cleaned}'")
        return cleaned
    
    def identify_hash(self, hash_string):
        hash_string = self.clean_hash(hash_string)
        length = len(hash_string)
        if length == 32:
            return 'md5'
        elif length == 40:
            return 'sha1'
        elif length == 64:
            return 'sha256'
        elif length == 128:
            return 'sha512'
        else:
            print(f"[-] Unknown hash length {length} for: {hash_string}")
            return None
    
    def compute_hash(self, password, algorithm):
        password = password.strip()
        try:
            if algorithm == 'md5':
                return hashlib.md5(password.encode()).hexdigest()
            elif algorithm == 'sha1':
                return hashlib.sha1(password.encode()).hexdigest()
            elif algorithm == 'sha256':
                return hashlib.sha256(password.encode()).hexdigest()
            elif algorithm == 'sha512':
                return hashlib.sha512(password.encode()).hexdigest()
            else:
                return None
        except Exception as e:
            print(f"[-] Error computing hash for '{password}': {e}")
            return None
    
    def load_wordlist(self, file_path, max_lines=None):
        if not os.path.exists(file_path):
            print(f"[-] Wordlist not found: {file_path}")
            return []
        
        passwords = []
        try:
            with open(file_path, 'r', encoding='utf-8', errors='ignore') as f:
                for line_num, line in enumerate(f, 1):
                    if max_lines and line_num > max_lines:
                        break
                    line = line.strip()
                    if line:
                        passwords.append(line)
            print(f"[+] Loaded {len(passwords)} passwords from {file_path}")
            return passwords
        except Exception as e:
            print(f"[-] Error loading wordlist: {e}")
            return []
    
    def load_hashes(self, file_path):
        """Load and clean hashes from file"""
        if not os.path.exists(file_path):
            print(f"[-] Hash file not found: {file_path}")
            return []
        
        hashes = []
        try:
            with open(file_path, 'r', encoding='utf-8', errors='ignore') as f:
                for line_num, line in enumerate(f, 1):
                    line = line.strip()
                    if line and not line.startswith('#'):
                        cleaned_hash = self.clean_hash(line)
                        if cleaned_hash:
                            hashes.append(cleaned_hash)
                        else:
                            print(f"[!] Skipping invalid hash on line {line_num}: {line}")
            return hashes
        except Exception as e:
            print(f"[-] Error loading hashes: {e}")
            return []
    
    def crack_multiple_hashes_parallel(self, hash_file_path, wordlist_path, threads=4):
        """Crack multiple hashes using parallel processing"""
        self.display_banner()
        
        # Load hashes
        hashes = self.load_hashes(hash_file_path)
        if not hashes:
            return
        
        print(f"[*] Loaded {len(hashes)} hashes from {hash_file_path}")
        
        # Load wordlist
        passwords = self.load_wordlist(wordlist_path)
        if not passwords:
            return
        
        print(f"[*] Starting batch attack with {threads} threads...")
        print(f"[*] Total combinations: {len(hashes)} hashes × {len(passwords)} passwords = {len(hashes)*len(passwords):,}")
        
        total_start = time.time()
        cracked_count = 0
        
        for i, target_hash in enumerate(hashes, 1):
            print(f"\n--- Cracking Hash {i}/{len(hashes)} ---")
            print(f"Hash: {target_hash}")
            
            hash_type = self.identify_hash(target_hash)
            if not hash_type:
                print("[-] Could not identify hash type, skipping...")
                continue
            
            start_time = time.time()
            found_password = None
            
            # Use parallel processing for each hash
            chunk_size = max(1, len(passwords) // threads)
            chunks = [passwords[j:j + chunk_size] for j in range(0, len(passwords), chunk_size)]
            
            with ProcessPoolExecutor(max_workers=threads) as executor:
                futures = []
                for chunk in chunks:
                    future = executor.submit(self.search_chunk, chunk, target_hash, hash_type)
                    futures.append(future)
                
                # Check results
                for future in futures:
                    result = future.result()
                    if result:
                        found_password = result
                        break
            
            elapsed = time.time() - start_time
            
            if found_password:
                print(f"🎉 CRACKED in {elapsed:.3f}s: {found_password}")
                cracked_count += 1
                
                self.results.append({
                    'password': found_password,
                    'hash': target_hash,
                    'algorithm': hash_type,
                    'time_taken': elapsed,
                    'passwords_tested': len(passwords)
                })
            else:
                print(f"❌ Not found after {elapsed:.3f}s")
        
        total_time = time.time() - total_start
        self.show_batch_summary(hashes, cracked_count, total_time, len(passwords))
    
    def search_chunk(self, chunk, target_hash, algorithm):
        """Search a chunk of passwords for the target hash"""
        for password in chunk:
            computed_hash = self.compute_hash(password, algorithm)
            if computed_hash == target_hash:
                return password
        return None
    
    def show_batch_summary(self, hashes, cracked_count, total_time, passwords_count):
        """Show detailed batch cracking summary"""
        print(f"\n{'='*60}")
        print("📊 BATCH CRACKING COMPLETE!")
        print(f"{'='*60}")
        print(f"⏱️  Total time: {total_time:.2f} seconds")
        print(f"🔑 Hashes cracked: {cracked_count}/{len(hashes)}")
        print(f"📈 Success rate: {(cracked_count/len(hashes))*100:.1f}%")
        print(f"⚡ Total operations: {len(hashes) * passwords_count:,}")
        print(f"🚀 Operations/second: {len(hashes) * passwords_count / total_time:,.0f}")
        
        if self.results:
            print(f"\n🔍 CRACKED PASSWORDS:")
            for result in self.results:
                print(f"  • {result['password']:12} -> {result['hash']}")
        
        # Show uncracked hashes
        cracked_hashes = set(result['hash'] for result in self.results)
        uncracked = [h for h in hashes if h not in cracked_hashes]
        if uncracked:
            print(f"\n❌ UNCRACKED HASHES ({len(uncracked)}):")
            for hash_val in uncracked:
                print(f"  • {hash_val}")
    
    def benchmark_system(self):
        """Benchmark system performance"""
        print("\n⚡ SYSTEM BENCHMARK")
        print("=" * 30)
        
        # Test different thread counts
        test_passwords = ['test' + str(i) for i in range(1000)]
        test_hash = '5f4dcc3b5aa765d61d8327deb882cf99'  # MD5 of 'test0'
        
        print(f"CPU Cores: {mp.cpu_count()}")
        print("Testing different thread configurations...")
        
        for workers in [1, 2, 4, 8, self.max_workers]:
            if workers > self.max_workers:
                continue
                
            start_time = time.time()
            chunk_size = max(1, len(test_passwords) // workers)
            chunks = [test_passwords[i:i + chunk_size] for i in range(0, len(test_passwords), chunk_size)]
            
            with ProcessPoolExecutor(max_workers=workers) as executor:
                futures = [executor.submit(self.search_chunk, chunk, test_hash, 'md5') for chunk in chunks]
                for future in futures:
                    future.result()
            
            elapsed = time.time() - start_time
            speed = len(test_passwords) / elapsed
            print(f"  {workers:2} threads: {speed:6.0f} hashes/sec")
    
    def interactive_mode(self):
        """Interactive mode for user-friendly operation"""
        self.display_banner()
        
        while True:
            print("\n" + "="*50)
            print("HashCracker Pro - Interactive Mode")
            print("="*50)
            print("1. Crack single hash")
            print("2. Crack multiple hashes (batch)")
            print("3. System benchmark")
            print("4. View results")
            print("5. Exit")
            
            choice = input("\nSelect option (1-5): ").strip()
            
            if choice == '1':
                self.interactive_single()
            elif choice == '2':
                self.interactive_batch()
            elif choice == '3':
                self.benchmark_system()
            elif choice == '4':
                self.show_results()
            elif choice == '5':
                print("👋 Thank you for using HashCracker Pro!")
                break
            else:
                print("❌ Invalid choice. Please try again.")
    
    def interactive_single(self):
        """Interactive single hash cracking"""
        print("\n🔍 SINGLE HASH CRACKING")
        target_hash = input("Enter target hash: ").strip()
        wordlist_path = input("Enter wordlist path: ").strip()
        threads = input("Enter threads (default 4): ").strip()
        threads = int(threads) if threads.isdigit() else 4
        
        if not os.path.exists(wordlist_path):
            print("❌ Wordlist file not found!")
            return
        
        self.crack_single_hash_interactive(target_hash, wordlist_path, threads)
    
    def interactive_batch(self):
        """Interactive batch cracking"""
        print("\n📁 BATCH HASH CRACKING")
        hash_file = input("Enter hash file path: ").strip()
        wordlist_path = input("Enter wordlist path: ").strip()
        threads = input("Enter threads (default 4): ").strip()
        threads = int(threads) if threads.isdigit() else 4
        
        if not os.path.exists(hash_file):
            print("❌ Hash file not found!")
            return
        if not os.path.exists(wordlist_path):
            print("❌ Wordlist file not found!")
            return
        
        self.crack_multiple_hashes_parallel(hash_file, wordlist_path, threads)
    
    def crack_single_hash_interactive(self, target_hash, wordlist_path, threads=4):
        """Crack single hash for interactive mode"""
        hash_type = self.identify_hash(target_hash)
        if not hash_type:
            print("❌ Could not identify hash type!")
            return
        
        passwords = self.load_wordlist(wordlist_path)
        if not passwords:
            return
        
        print(f"[*] Cracking hash: {target_hash}")
        print(f"[*] Using {threads} threads...")
        
        start_time = time.time()
        found_password = None
        
        chunk_size = max(1, len(passwords) // threads)
        chunks = [passwords[i:i + chunk_size] for i in range(0, len(passwords), chunk_size)]
        
        with ProcessPoolExecutor(max_workers=threads) as executor:
            futures = [executor.submit(self.search_chunk, chunk, target_hash, hash_type) for chunk in chunks]
            
            for i, future in enumerate(futures):
                result = future.result()
                if result:
                    found_password = result
                    break
                print(f"[*] Progress: {(i+1)*chunk_size}/{len(passwords)}")
        
        elapsed = time.time() - start_time
        
        if found_password:
            print(f"\n🎉 SUCCESS! Password: {found_password}")
            print(f"⏱️  Time: {elapsed:.3f} seconds")
        else:
            print(f"\n❌ Password not found after {elapsed:.3f} seconds")
    
    def show_results(self):
        """Show all cracking results"""
        if not self.results:
            print("📭 No results to show")
            return
        
        print(f"\n📊 CRACKING RESULTS ({len(self.results)} hashes cracked)")
        print("=" * 50)
        for i, result in enumerate(self.results, 1):
            print(f"{i:2}. {result['password']:12} -> {result['hash']} ({result['algorithm']})")

def main():
    parser = argparse.ArgumentParser(description='HashCracker Pro - Enhanced Edition')
    parser.add_argument('--hash', help='Single hash to crack')
    parser.add_argument('--hash-file', help='File containing multiple hashes')
    parser.add_argument('--wordlist', help='Wordlist file path')
    parser.add_argument('--threads', type=int, default=4, help='Number of threads')
    parser.add_argument('--mode', choices=['single', 'batch', 'interactive', 'benchmark'], 
                       default='interactive', help='Operation mode')
    
    args = parser.parse_args()
    
    cracker = EnhancedHashCracker()
    
    if args.mode == 'single' and args.hash and args.wordlist:
        cracker.crack_single_hash_interactive(args.hash, args.wordlist, args.threads)
    elif args.mode == 'batch' and args.hash_file and args.wordlist:
        cracker.crack_multiple_hashes_parallel(args.hash_file, args.wordlist, args.threads)
    elif args.mode == 'benchmark':
        cracker.benchmark_system()
    elif args.mode == 'interactive':
        cracker.interactive_mode()
    else:
        print("❌ Invalid arguments. Use --help for usage information.")

if __name__ == '__main__':
    main()