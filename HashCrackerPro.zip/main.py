﻿#!/usr/bin/env python3
"""
HASHCRACKER PRO - Main Entry Point
Parallel Password Auditing System
"""

import argparse
import sys
import os

try:
    from src.interfaces.cli import CLIInterface
except ImportError as e:
    print(f"Error importing modules: {e}")
    print("Installing required dependencies...")
    os.system("pip install pyyaml bcrypt psutil tqdm")
    
    # Try again after install
    try:
        from src.interfaces.cli import CLIInterface
    except ImportError:
        print("Please install dependencies manually: pip install pyyaml bcrypt psutil tqdm")
        sys.exit(1)

def main():
    parser = argparse.ArgumentParser(description="HASHCRACKER PRO - Parallel Password Auditing System")
    parser.add_argument('--hash', help='Hash to crack')
    parser.add_argument('--hash-type', help='Type of hash algorithm')
    parser.add_argument('--wordlist', help='Path to wordlist file')
    parser.add_argument('--attack', choices=['dictionary', 'bruteforce', 'hybrid'], default='dictionary')
    parser.add_argument('--threads', type=int, default=4, help='Number of parallel threads')
    
    args = parser.parse_args()
    
    cli = CLIInterface()
    
    if args.hash:
        # Command line mode
        cli.run_from_args(args)
    else:
        # Interactive mode
        cli.run_interactive()

if __name__ == "__main__":
    main()