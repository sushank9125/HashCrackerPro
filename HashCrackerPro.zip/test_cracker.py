# test_cracker.py - Enhanced version with debugging
import hashlib
import multiprocessing as mp
from concurrent.futures import ProcessPoolExecutor
import time
import os

class TestCracker:
    def __init__(self, max_workers=None):
        self.max_workers = max_workers or mp.cpu_count()
        print(f"[DEBUG] Using {self.max_workers} workers")
    
    def identify_hash(self, hash_string):
        length = len(hash_string)
        print(f"[DEBUG] Hash length: {length}")
        if length == 32:
            return 'md5'
        elif length == 40:
            return 'sha1'
        elif length == 64:
            return 'sha256'
        elif length == 128:
            return 'sha512'
        else:
            return None
    
    def compute_hash(self, password, algorithm):
        password = password.strip()
        print(f"[DEBUG] Testing: '{password}'")
        
        if algorithm == 'md5':
            result = hashlib.md5(password.encode()).hexdigest()
            print(f"[DEBUG] Computed MD5: {result}")
            return result
        elif algorithm == 'sha1':
            return hashlib.sha1(password.encode()).hexdigest()
        elif algorithm == 'sha256':
            return hashlib.sha256(password.encode()).hexdigest()
        elif algorithm == 'sha512':
            return hashlib.sha512(password.encode()).hexdigest()
        else:
            return None
    
    def load_wordlist(self, file_path):
        if not os.path.exists(file_path):
            print(f"[-] Wordlist not found: {file_path}")
            return []
        
        passwords = []
        try:
            with open(file_path, 'r', encoding='utf-8', errors='ignore') as f:
                for line_num, line in enumerate(f, 1):
                    line = line.strip()
                    if line:
                        passwords.append(line)
                        if line_num <= 5:  # Show first 5 passwords
                            print(f"[DEBUG] Loaded password #{line_num}: '{line}'")
            return passwords
        except Exception as e:
            print(f"[-] Error loading wordlist: {e}")
            return []
    
    def crack_hash(self, target_hash, wordlist_path, hash_type=None, threads=4):
        banner = """
        ╔═══════════════════════════════════════════════╗
        ║              HASHCRACKER PRO                  ║
        ║        Parallel Password Auditing System      ║
        ║                                               ║
        ║           [Debug Edition]                     ║
        ╚═══════════════════════════════════════════════╝
        """
        print(banner)
        
        print(f"[DEBUG] Target hash: {target_hash}")
        
        # Auto-detect hash type
        if not hash_type:
            hash_type = self.identify_hash(target_hash)
            if not hash_type:
                print("[-] Could not identify hash type")
                return
            print(f"[*] Auto-detected: {hash_type}")
        else:
            print(f"[*] Using specified type: {hash_type}")
        
        # Load wordlist
        print(f"[*] Loading wordlist: {wordlist_path}")
        passwords = self.load_wordlist(wordlist_path)
        if not passwords:
            print("[-] No passwords loaded!")
            return
        
        print(f"[*] Loaded {len(passwords)} passwords")
        print(f"[*] Starting attack with {threads} threads...")
        
        start_time = time.time()
        found_password = None
        
        # Test first few passwords to verify hashing works
        print("\n[DEBUG] Testing first 3 passwords:")
        for i, pwd in enumerate(passwords[:3]):
            computed = self.compute_hash(pwd, hash_type)
            print(f"[DEBUG] '{pwd}' -> {computed}")
            if computed == target_hash:
                found_password = pwd
                print(f"[DEBUG] MATCH FOUND: {pwd}")
                break
        
        if found_password:
            elapsed = time.time() - start_time
            print(f"\n[+] SUCCESS! Password found in {elapsed:.2f} seconds")
            print(f"[+] Password: {found_password}")
            print(f"[+] Hash: {target_hash}")
            return
        
        # If not found in first 3, search all
        print("\n[*] Searching entire wordlist...")
        for password in passwords:
            computed_hash = self.compute_hash(password, hash_type)
            if computed_hash == target_hash:
                found_password = password
                break
        
        elapsed = time.time() - start_time
        
        if found_password:
            print(f"\n[+] SUCCESS! Password found in {elapsed:.2f} seconds")
            print(f"[+] Password: {found_password}")
            print(f"[+] Hash: {target_hash}")
        else:
            print(f"\n[-] Password not found after {elapsed:.2f} seconds")
            print(f"[*] Searched {len(passwords)} passwords")
            print(f"[*] First password in list: '{passwords[0] if passwords else 'None'}'")

def main():
    import argparse
    
    parser = argparse.ArgumentParser(description='HashCracker Pro - Debug Edition')
    parser.add_argument('--hash', required=True, help='Hash to crack')
    parser.add_argument('--wordlist', required=True, help='Wordlist file path')
    parser.add_argument('--hash-type', help='Hash algorithm type')
    parser.add_argument('--threads', type=int, default=4, help='Number of threads')
    
    args = parser.parse_args()
    
    cracker = TestCracker()
    cracker.crack_hash(args.hash, args.wordlist, args.hash_type, args.threads)

if __name__ == '__main__':
    main()