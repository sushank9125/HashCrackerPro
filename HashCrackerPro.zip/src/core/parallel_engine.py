﻿import multiprocessing as mp
import threading
from concurrent.futures import ProcessPoolExecutor, ThreadPoolExecutor
from queue import Queue
from typing import List, Callable, Any
import hashlib

class ParallelEngine:
    """
    Parallel computing engine for hash cracking operations
    Supports both multiprocessing and multithreading
    """
    
    def __init__(self, max_workers=None, mode='process'):
        self.max_workers = max_workers or mp.cpu_count()
        self.mode = mode  # 'process' or 'thread'
        self.results_queue = Queue()
        self.stop_event = threading.Event()
        
    def process_chunk(self, chunk: List[str], hash_target: str, algorithm: str) -> List[tuple]:
        """
        Process a chunk of passwords in parallel
        """
        results = []
        for password in chunk:
            if self.stop_event.is_set():
                break
                
            if self.verify_hash(password.strip(), hash_target, algorithm):
                results.append((password.strip(), hash_target))
                self.stop_event.set()  # Stop other workers if found
                
        return results
    
    def verify_hash(self, password: str, target_hash: str, algorithm: str) -> bool:
        """
        Verify if password matches target hash
        """
        try:
            if algorithm == 'md5':
                computed_hash = hashlib.md5(password.encode()).hexdigest()
            elif algorithm == 'sha1':
                computed_hash = hashlib.sha1(password.encode()).hexdigest()
            elif algorithm == 'sha256':
                computed_hash = hashlib.sha256(password.encode()).hexdigest()
            elif algorithm == 'sha512':
                computed_hash = hashlib.sha512(password.encode()).hexdigest()
            else:
                return False
                
            return computed_hash == target_hash
        except Exception:
            return False
    
    def split_workload(self, data: List[Any], chunk_size: int) -> List[List[Any]]:
        """
        Split data into chunks for parallel processing
        """
        return [data[i:i + chunk_size] for i in range(0, len(data), chunk_size)]
    
    def parallel_crack(self, passwords: List[str], hash_target: str, 
                      algorithm: str, chunk_size: int = 1000) -> List[tuple]:
        """
        Main parallel cracking function
        """
        self.stop_event.clear()
        chunks = self.split_workload(passwords, chunk_size)
        results = []
        
        if self.mode == 'process':
            with ProcessPoolExecutor(max_workers=self.max_workers) as executor:
                futures = [
                    executor.submit(
                        self.process_chunk, 
                        chunk, 
                        hash_target, 
                        algorithm
                    ) for chunk in chunks
                ]
                
                for future in futures:
                    chunk_results = future.result()
                    results.extend(chunk_results)
                    if chunk_results and self.stop_event.is_set():
                        # Cancel remaining futures
                        for f in futures:
                            f.cancel()
                        break
                        
        else:  # Thread mode
            with ThreadPoolExecutor(max_workers=self.max_workers) as executor:
                futures = [
                    executor.submit(
                        self.process_chunk, 
                        chunk, 
                        hash_target, 
                        algorithm
                    ) for chunk in chunks
                ]
                
                for future in futures:
                    chunk_results = future.result()
                    results.extend(chunk_results)
                    if chunk_results and self.stop_event.is_set():
                        # Cancel remaining futures
                        for f in futures:
                            f.cancel()
                        break
        
        return results
    
    def get_system_info(self) -> dict:
        """
        Get system information for performance tuning
        """
        return {
            'cpu_count': mp.cpu_count(),
            'available_memory': self.get_available_memory(),
        }
    
    def get_available_memory(self) -> int:
        """
        Get available system memory in MB
        """
        try:
            import psutil
            return psutil.virtual_memory().available // (1024 * 1024)
        except ImportError:
            return 0
