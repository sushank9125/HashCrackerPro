﻿import hashlib
from typing import Optional

class HashProcessor:
    """
    Handles different hash algorithms and their verification
    """
    
    SUPPORTED_ALGORITHMS = ['md5', 'sha1', 'sha256', 'sha512']
    
    @classmethod
    def identify_hash(cls, hash_string: str) -> Optional[str]:
        """
        Identify hash type based on pattern
        """
        hash_length = len(hash_string)
        
        if hash_length == 32:
            return 'md5'
        elif hash_length == 40:
            return 'sha1'
        elif hash_length == 64:
            return 'sha256'
        elif hash_length == 128:
            return 'sha512'
        else:
            return None
    
    @classmethod
    def compute_hash(cls, password: str, algorithm: str) -> str:
        """
        Compute hash of a password using specified algorithm
        """
        if algorithm == 'md5':
            return hashlib.md5(password.encode()).hexdigest()
        elif algorithm == 'sha1':
            return hashlib.sha1(password.encode()).hexdigest()
        elif algorithm == 'sha256':
            return hashlib.sha256(password.encode()).hexdigest()
        elif algorithm == 'sha512':
            return hashlib.sha512(password.encode()).hexdigest()
        else:
            raise ValueError(f"Unsupported algorithm: {algorithm}")
