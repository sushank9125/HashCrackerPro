import json
import csv
import time
from typing import List, Tuple, Dict, Any
from datetime import datetime

class ResultManager:
    """
    Manages cracking results and exports
    """
    
    def __init__(self):
        self.results = []
        self.session_start = datetime.now()
    
    def add_result(self, password: str, hash_value: str, algorithm: str, 
                  attack_mode: str, time_taken: float):
        """
        Add a cracking result
        """
        result = {
            'password': password,
            'hash': hash_value,
            'algorithm': algorithm,
            'attack_mode': attack_mode,
            'time_taken': time_taken,
            'timestamp': datetime.now().isoformat()
        }
        self.results.append(result)
    
    def export_json(self, filename: str):
        """
        Export results to JSON file
        """
        data = {
            'session_start': self.session_start.isoformat(),
            'session_end': datetime.now().isoformat(),
            'total_cracked': len(self.results),
            'results': self.results
        }
        
        with open(filename, 'w', encoding='utf-8') as f:
            json.dump(data, f, indent=2)
        
        print(f"[+] Results exported to {filename}")
    
    def export_csv(self, filename: str):
        """
        Export results to CSV file
        """
        with open(filename, 'w', newline='', encoding='utf-8') as f:
            if self.results:
                writer = csv.DictWriter(f, fieldnames=self.results[0].keys())
                writer.writeheader()
                writer.writerows(self.results)
        
        print(f"[+] Results exported to {filename}")
    
    def export_txt(self, filename: str):
        """
        Export results to text file
        """
        with open(filename, 'w', encoding='utf-8') as f:
            f.write(f"HashCracker Pro Results\n")
            f.write(f"Session: {self.session_start}\n")
            f.write(f"Total Cracked: {len(self.results)}\n")
            f.write("=" * 50 + "\n")
            
            for result in self.results:
                f.write(f"Password: {result['password']}\n")
                f.write(f"Hash: {result['hash']}\n")
                f.write(f"Algorithm: {result['algorithm']}\n")
                f.write(f"Attack: {result['attack_mode']}\n")
                f.write(f"Time: {result['time_taken']:.2f}s\n")
                f.write("-" * 30 + "\n")
        
        print(f"[+] Results exported to {filename}")
    
    def get_statistics(self) -> Dict[str, Any]:
        """
        Get cracking statistics
        """
        if not self.results:
            return {}
            
        algorithms = {}
        attack_modes = {}
        
        for result in self.results:
            algo = result['algorithm']
            attack = result['attack_mode']
            
            algorithms[algo] = algorithms.get(algo, 0) + 1
            attack_modes[attack] = attack_modes.get(attack, 0) + 1
        
        total_time = sum(result['time_taken'] for result in self.results)
        
        return {
            'total_cracked': len(self.results),
            'algorithms': algorithms,
            'attack_modes': attack_modes,
            'total_time': total_time,
            'average_time': total_time / len(self.results) if self.results else 0,
            'session_duration': (datetime.now() - self.session_start).total_seconds()
        }
    
    def clear_results(self):
        """
        Clear all results
        """
        self.results.clear()
        self.session_start = datetime.now()