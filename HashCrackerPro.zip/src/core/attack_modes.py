import itertools
import string
from typing import List, Generator
from src.utils.password_generator import PasswordGenerator

class AttackModes:
    """
    Different attack modes for password cracking
    """
    
    def __init__(self):
        self.password_gen = PasswordGenerator()
    
    def dictionary_attack(self, wordlist: List[str]) -> Generator[str, None, None]:
        """
        Standard dictionary attack
        """
        for word in wordlist:
            yield word.strip()
    
    def brute_force_attack(self, min_length: int = 1, max_length: int = 8, 
                          charset: str = string.ascii_lowercase) -> Generator[str, None, None]:
        """
        Brute force attack with configurable parameters
        """
        for length in range(min_length, max_length + 1):
            for combination in itertools.product(charset, repeat=length):
                yield ''.join(combination)
    
    def hybrid_attack(self, wordlist: List[str], rules: List[str] = None) -> Generator[str, None, None]:
        """
        Hybrid attack combining dictionary and rules
        """
        # Basic rule implementations
        basic_rules = [
            lambda x: x,                           # Original
            lambda x: x.upper(),                  # Uppercase
            lambda x: x.capitalize(),             # Capitalize
            lambda x: x + '123',                  # Append numbers
            lambda x: x + '!',                    # Append special char
            lambda x: x[::-1],                    # Reverse
        ]
        
        rules_to_apply = rules or basic_rules
        
        for word in wordlist:
            word = word.strip()
            for rule in rules_to_apply:
                try:
                    yield rule(word)
                except:
                    continue
    
    def mask_attack(self, mask: str, charset: dict = None) -> Generator[str, None, None]:
        """
        Mask attack for targeted brute force
        """
        default_charset = {
            '?l': string.ascii_lowercase,
            '?u': string.ascii_uppercase,
            '?d': string.digits,
            '?s': string.punctuation,
            '?a': string.ascii_letters + string.digits + string.punctuation
        }
        
        charset = charset or default_charset
        return self.password_gen.generate_from_mask(mask, charset)