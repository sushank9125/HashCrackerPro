import bcrypt
from typing import Optional

class BcryptCracker:
    """
    Bcrypt hash cracking implementation
    """
    
    def __init__(self):
        self.algorithm = 'bcrypt'
    
    def compute_hash(self, password: str) -> str:
        """
        Compute bcrypt hash of a password
        """
        return bcrypt.hashpw(password.encode(), bcrypt.gensalt()).decode()
    
    def verify_hash(self, password: str, target_hash: str) -> bool:
        """
        Verify if password matches target bcrypt hash
        """
        try:
            return bcrypt.checkpw(password.encode(), target_hash.encode())
        except Exception:
            return False
    
    def identify(self, hash_string: str) -> bool:
        """
        Identify if string is a bcrypt hash
        """
        return (hash_string.startswith('$2a$') or 
                hash_string.startswith('$2b$') or
                hash_string.startswith('$2y$'))