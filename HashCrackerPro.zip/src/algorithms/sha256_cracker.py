import hashlib
from typing import Optional

class SHA256Cracker:
    """
    SHA-256 hash cracking implementation
    """
    
    def __init__(self):
        self.algorithm = 'sha256'
    
    def compute_hash(self, password: str) -> str:
        """
        Compute SHA-256 hash of a password
        """
        return hashlib.sha256(password.encode()).hexdigest()
    
    def verify_hash(self, password: str, target_hash: str) -> bool:
        """
        Verify if password matches target SHA-256 hash
        """
        return self.compute_hash(password) == target_hash
    
    def identify(self, hash_string: str) -> bool:
        """
        Identify if string is a SHA-256 hash
        """
        return len(hash_string) == 64 and all(c in '0123456789abcdef' for c in hash_string)