import hashlib
from typing import Optional

class MD5Cracker:
    """
    MD5 hash cracking implementation
    """
    
    def __init__(self):
        self.algorithm = 'md5'
    
    def compute_hash(self, password: str) -> str:
        """
        Compute MD5 hash of a password
        """
        return hashlib.md5(password.encode()).hexdigest()
    
    def verify_hash(self, password: str, target_hash: str) -> bool:
        """
        Verify if password matches target MD5 hash
        """
        return self.compute_hash(password) == target_hash
    
    def identify(self, hash_string: str) -> bool:
        """
        Identify if string is an MD5 hash
        """
        return len(hash_string) == 32 and all(c in '0123456789abcdef' for c in hash_string)