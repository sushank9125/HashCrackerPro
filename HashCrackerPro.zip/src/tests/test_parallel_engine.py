import unittest
import time
from src.core.parallel_engine import ParallelEngine

class TestParallelEngine(unittest.TestCase):
    
    def setUp(self):
        self.engine = ParallelEngine(max_workers=2)
    
    def test_verify_hash_correct(self):
        password = "password"
        target_hash = "5f4dcc3b5aa765d61d8327deb882cf99"  # MD5 of "password"
        self.assertTrue(self.engine.verify_hash(password, target_hash, 'md5'))
    
    def test_verify_hash_incorrect(self):
        password = "wrongpassword"
        target_hash = "5f4dcc3b5aa765d61d8327deb882cf99"  # MD5 of "password"
        self.assertFalse(self.engine.verify_hash(password, target_hash, 'md5'))
    
    def test_split_workload(self):
        data = list(range(100))
        chunks = self.engine.split_workload(data, 10)
        self.assertEqual(len(chunks), 10)
        self.assertEqual(sum(len(chunk) for chunk in chunks), 100)

if __name__ == '__main__':
    unittest.main()