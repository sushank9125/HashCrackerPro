import unittest
from src.core.hash_processor import HashProcessor

class TestHashProcessor(unittest.TestCase):
    
    def setUp(self):
        self.processor = HashProcessor()
    
    def test_identify_md5(self):
        md5_hash = "5f4dcc3b5aa765d61d8327deb882cf99"
        self.assertEqual(self.processor.identify_hash(md5_hash), 'md5')
    
    def test_identify_sha1(self):
        sha1_hash = "5baa61e4c9b93f3f0682250b6cf8331b7ee68fd8"
        self.assertEqual(self.processor.identify_hash(sha1_hash), 'sha1')
    
    def test_compute_md5(self):
        password = "password"
        expected_hash = "5f4dcc3b5aa765d61d8327deb882cf99"
        self.assertEqual(self.processor.compute_hash(password, 'md5'), expected_hash)
    
    def test_verify_hash(self):
        password = "test123"
        algorithm = 'md5'
        computed_hash = self.processor.compute_hash(password, algorithm)
        self.assertTrue(self.processor.verify_hash(password, computed_hash, algorithm))

if __name__ == '__main__':
    unittest.main()