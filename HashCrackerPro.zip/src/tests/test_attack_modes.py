import unittest
from src.core.attack_modes import AttackModes

class TestAttackModes(unittest.TestCase):
    
    def setUp(self):
        self.attack_modes = AttackModes()
    
    def test_dictionary_attack(self):
        wordlist = ["password", "123456", "admin"]
        passwords = list(self.attack_modes.dictionary_attack(wordlist))
        self.assertEqual(passwords, ["password", "123456", "admin"])
    
    def test_hybrid_attack(self):
        wordlist = ["test"]
        passwords = list(self.attack_modes.hybrid_attack(wordlist))
        # Should generate variations of "test"
        self.assertIn("TEST", passwords)  # Uppercase
        self.assertIn("test1", passwords)  # Append 1

if __name__ == '__main__':
    unittest.main()