"""
Test modules for HashCracker Pro
"""