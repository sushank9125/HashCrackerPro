﻿from typing import List

class FileHandler:
    """
    Handles file operations for wordlists and hash files
    """
    
    @staticmethod
    def load_wordlist(file_path: str) -> List[str]:
        """
        Load wordlist from file
        """
        try:
            with open(file_path, 'r', encoding='utf-8', errors='ignore') as file:
                return file.readlines()
        except FileNotFoundError:
            print(f"[-] Wordlist file not found: {file_path}")
            return []
        except Exception as e:
            print(f"[-] Error loading wordlist: {str(e)}")
            return []
    
    @staticmethod
    def load_hashes(file_path: str) -> List[str]:
        """
        Load hashes from file
        """
        try:
            with open(file_path, 'r') as file:
                return [line.strip() for line in file if line.strip()]
        except FileNotFoundError:
            print(f"[-] Hash file not found: {file_path}")
            return []
    
    @staticmethod
    def save_results(results: List[tuple], output_file: str):
        """
        Save cracking results to file
        """
        try:
            with open(output_file, 'w') as file:
                for password, hash_value in results:
                    file.write(f"{password}:{hash_value}\n")
            print(f"[+] Results saved to: {output_file}")
        except Exception as e:
            print(f"[-] Error saving results: {str(e)}")
