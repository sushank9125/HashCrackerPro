import time
import hashlib
from typing import Dict, Any
from src.core.parallel_engine import ParallelEngine

class Benchmark:
    """
    Performance benchmarking utilities
    """
    
    @staticmethod
    def benchmark_hash_speed(algorithm: str, sample_size: int = 10000) -> Dict[str, Any]:
        """
        Benchmark hash computation speed
        """
        test_data = ['test_password_' + str(i) for i in range(sample_size)]
        
        start_time = time.time()
        
        if algorithm == 'md5':
            for data in test_data:
                hashlib.md5(data.encode()).hexdigest()
        elif algorithm == 'sha1':
            for data in test_data:
                hashlib.sha1(data.encode()).hexdigest()
        elif algorithm == 'sha256':
            for data in test_data:
                hashlib.sha256(data.encode()).hexdigest()
        elif algorithm == 'sha512':
            for data in test_data:
                hashlib.sha512(data.encode()).hexdigest()
        
        elapsed = time.time() - start_time
        hashes_per_second = sample_size / elapsed
        
        return {
            'algorithm': algorithm,
            'hashes_per_second': hashes_per_second,
            'time_elapsed': elapsed,
            'sample_size': sample_size
        }
    
    @staticmethod
    def benchmark_parallel_performance() -> Dict[str, Any]:
        """
        Benchmark parallel processing performance
        """
        engine = ParallelEngine()
        system_info = engine.get_system_info()
        
        # Test different worker counts
        worker_results = {}
        test_passwords = ['test' + str(i) for i in range(5000)]
        test_hash = '5f4dcc3b5aa765d61d8327deb882cf99'  # MD5 of 'test0'
        
        for workers in [1, 2, 4, 8, engine.max_workers]:
            if workers > engine.max_workers:
                continue
                
            start_time = time.time()
            engine.max_workers = workers
            results = engine.parallel_crack(test_passwords[:1000], test_hash, 'md5', 100)
            elapsed = time.time() - start_time
            
            worker_results[workers] = {
                'time_seconds': elapsed,
                'passwords_per_second': 1000 / elapsed,
                'efficiency': (1000 / elapsed) / workers  # Passwords per second per worker
            }
        
        return {
            'system_info': system_info,
            'worker_performance': worker_results,
            'recommended_workers': max(worker_results.items(), 
                                     key=lambda x: x[1]['efficiency'])[0]
        }
    
    @staticmethod
    def run_complete_benchmark() -> Dict[str, Any]:
        """
        Run complete system benchmark
        """
        print("[*] Starting comprehensive benchmark...")
        
        results = {
            'hash_speeds': {},
            'parallel_performance': {},
            'timestamp': time.time()
        }
        
        # Benchmark hash algorithms
        algorithms = ['md5', 'sha1', 'sha256', 'sha512']
        for algo in algorithms:
            print(f"[*] Benchmarking {algo}...")
            results['hash_speeds'][algo] = Benchmark.benchmark_hash_speed(algo)
        
        # Benchmark parallel performance
        print("[*] Benchmarking parallel performance...")
        results['parallel_performance'] = Benchmark.benchmark_parallel_performance()
        
        print("[+] Benchmark completed!")
        return results