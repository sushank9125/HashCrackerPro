import itertools
import string
from typing import Generator, Dict, Optional

class PasswordGenerator:
    """
    Generates passwords for brute force and mask attacks
    """
    
    DEFAULT_CHARSETS = {
        '?l': string.ascii_lowercase,
        '?u': string.ascii_uppercase,
        '?d': string.digits,
        '?s': string.punctuation,
        '?a': string.ascii_letters + string.digits + string.punctuation,
        '?h': string.hexdigits.lower(),
        '?H': string.hexdigits.upper(),
    }
    
    def generate_from_mask(self, mask: str, custom_charset: Optional[Dict] = None) -> Generator[str, None, None]:
        """
        Generate passwords from a mask pattern
        """
        charset = {**self.DEFAULT_CHARSETS, **(custom_charset or {})}
        
        # Parse mask and create product sets
        positions = []
        i = 0
        while i < len(mask):
            if mask[i] == '?':
                # Special charset
                if i + 1 < len(mask):
                    char_code = mask[i:i+2]
                    if char_code in charset:
                        positions.append(charset[char_code])
                        i += 2
                    else:
                        # Unknown charset, treat as literal
                        positions.append(mask[i])
                        i += 1
                else:
                    positions.append(mask[i])
                    i += 1
            else:
                # Literal character
                positions.append(mask[i])
                i += 1
        
        # Generate combinations
        for combination in itertools.product(*positions):
            yield ''.join(combination)
    
    def generate_brute_force(self, min_len: int, max_len: int, 
                           charset: str = string.ascii_lowercase) -> Generator[str, None, None]:
        """
        Generate passwords for brute force attack
        """
        for length in range(min_len, max_len + 1):
            for combination in itertools.product(charset, repeat=length):
                yield ''.join(combination)
    
    def generate_from_base(self, base_words: list, rules: list) -> Generator[str, None, None]:
        """
        Generate passwords by applying rules to base words
        """
        for word in base_words:
            for rule in rules:
                try:
                    yield rule(word)
                except:
                    continue
    
    def estimate_time(self, mask: str, speed: int = 1000) -> float:
        """
        Estimate time to complete a mask attack
        """
        total = 1
        for char in mask:
            if char == '?l':
                total *= 26
            elif char == '?u':
                total *= 26
            elif char == '?d':
                total *= 10
            elif char == '?s':
                total *= 32
            elif char == '?a':
                total *= 94
            else:
                total *= 1  # Literal character
        
        return total / speed  # seconds