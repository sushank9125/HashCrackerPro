import yaml
import os
from typing import Dict, Any

class ConfigLoader:
    """
    Configuration file loader and manager
    """
    
    DEFAULT_CONFIG = {
        'parallel': {
            'max_workers': 4,
            'mode': 'process',
            'chunk_size': 1000
        },
        'attack': {
            'default_mode': 'dictionary',
            'brute_force': {
                'min_length': 1,
                'max_length': 8,
                'charset': '?l?u?d?s'
            }
        },
        'performance': {
            'benchmark': True,
            'progress_update': 1000
        },
        'wordlists': {
            'default_path': './data/wordlists/',
            'common_wordlists': [
                'common_passwords.txt',
                'rockyou.txt'
            ]
        },
        'logging': {
            'level': 'INFO',
            'file': 'hashcracker.log'
        }
    }
    
    def __init__(self, config_path: str = 'config/default_config.yaml'):
        self.config_path = config_path
        self.config = self.DEFAULT_CONFIG.copy()
        self.load_config()
    
    def load_config(self):
        """
        Load configuration from YAML file
        """
        if os.path.exists(self.config_path):
            try:
                with open(self.config_path, 'r') as f:
                    loaded_config = yaml.safe_load(f) or {}
                    self._deep_update(self.config, loaded_config)
                print(f"[+] Configuration loaded from {self.config_path}")
            except Exception as e:
                print(f"[-] Error loading config: {e}. Using defaults.")
        else:
            print(f"[-] Config file not found: {self.config_path}. Using defaults.")
            self.create_default_config()
    
    def create_default_config(self):
        """
        Create default configuration file
        """
        os.makedirs(os.path.dirname(self.config_path), exist_ok=True)
        try:
            with open(self.config_path, 'w') as f:
                yaml.dump(self.DEFAULT_CONFIG, f, default_flow_style=False)
            print(f"[+] Default configuration created at {self.config_path}")
        except Exception as e:
            print(f"[-] Error creating config file: {e}")
    
    def _deep_update(self, original: Dict[Any, Any], update: Dict[Any, Any]):
        """
        Recursively update a dictionary
        """
        for key, value in update.items():
            if isinstance(value, dict) and key in original and isinstance(original[key], dict):
                self._deep_update(original[key], value)
            else:
                original[key] = value
    
    def get(self, key: str, default=None):
        """
        Get configuration value by key
        """
        keys = key.split('.')
        value = self.config
        try:
            for k in keys:
                value = value[k]
            return value
        except (KeyError, TypeError):
            return default
    
    def set(self, key: str, value: Any):
        """
        Set configuration value
        """
        keys = key.split('.')
        config = self.config
        for k in keys[:-1]:
            if k not in config:
                config[k] = {}
            config = config[k]
        config[keys[-1]] = value
    
    def save_config(self):
        """
        Save current configuration to file
        """
        try:
            os.makedirs(os.path.dirname(self.config_path), exist_ok=True)
            with open(self.config_path, 'w') as f:
                yaml.dump(self.config, f, default_flow_style=False)
            print(f"[+] Configuration saved to {self.config_path}")
        except Exception as e:
            print(f"[-] Error saving config: {e}")