"""
User interface modules
"""

from .cli import CLIInterface

# Remove WebDashboard import to avoid Flask dependency
# from .web_dashboard import WebDashboard

__all__ = ['CLIInterface']  # Remove 'WebDashboard'