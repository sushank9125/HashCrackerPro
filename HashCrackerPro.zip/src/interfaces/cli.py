﻿import argparse
import time
import os
import sys
from src.core.parallel_engine import ParallelEngine
from src.core.hash_processor import HashProcessor
from src.utils.file_handlers import FileHandler

class CLIInterface:
    """
    Command Line Interface for HashCracker Pro
    """
    
    def __init__(self):
        self.engine = ParallelEngine()
        self.hash_processor = HashProcessor()
        self.file_handler = FileHandler()
    
    def display_banner(self):
        banner = """
        ╔═══════════════════════════════════════════════╗
        ║              HASHCRACKER PRO                  ║
        ║        Parallel Password Auditing System      ║
        ║                                               ║
        ║           [Parallel Computing Edition]        ║
        ╚═══════════════════════════════════════════════╝
        """
        print(banner)
    
    def run(self):
        self.display_banner()
        
        parser = argparse.ArgumentParser(description="HASHCRACKER PRO CLI")
        parser.add_argument('--hash', help='Target hash to crack')
        parser.add_argument('--hash-type', help='Hash algorithm type')
        parser.add_argument('--wordlist', help='Path to wordlist file')
        parser.add_argument('--attack', choices=['dictionary', 'bruteforce', 'hybrid'], 
                          default='dictionary', help='Attack mode')
        parser.add_argument('--threads', type=int, default=4, help='Number of parallel threads')
        
        # Parse arguments from command line
        if len(sys.argv) > 1:
            args = parser.parse_args()
        else:
            # Interactive mode if no arguments provided
            args = argparse.Namespace()
            args.hash = input("Enter target hash: ")
            args.hash_type = input("Enter hash type (or press Enter to auto-detect): ") or None
            args.wordlist = input("Enter wordlist path: ")
            args.threads = int(input("Enter number of threads (default 4): ") or "4")
            args.attack = 'dictionary'
        
        # Auto-detect hash type if not provided
        if not args.hash_type:
            args.hash_type = self.hash_processor.identify_hash(args.hash)
            if not args.hash_type:
                print("[-] Could not identify hash type. Please specify with --hash-type")
                return
            else:
                print(f"[*] Auto-detected hash type: {args.hash_type}")
        
        print(f"[*] Starting attack on {args.hash_type} hash: {args.hash}")
        print(f"[*] Using {args.threads} parallel workers")
        
        # Verify wordlist exists
        if not os.path.exists(args.wordlist):
            print(f"[-] Wordlist file not found: {args.wordlist}")
            return
        
        start_time = time.time()
        
        try:
            # Load wordlist
            passwords = self.file_handler.load_wordlist(args.wordlist)
            if not passwords:
                print("[-] No passwords loaded from wordlist")
                return
                
            print(f"[*] Loaded {len(passwords)} passwords from wordlist")
            
            # Execute attack
            engine = ParallelEngine(max_workers=args.threads)
            results = engine.parallel_crack(passwords, args.hash, args.hash_type)
            
            if results:
                print(f"\n[+] SUCCESS: Password found!")
                for password, hash_value in results:
                    print(f"[+] Password: {password}")
                    print(f"[+] Hash: {hash_value}")
            else:
                print(f"\n[-] Password not found in the current attack")
                
        except Exception as e:
            print(f"[-] Error during attack: {str(e)}")
        
        elapsed_time = time.time() - start_time
        print(f"\n[*] Attack completed in {elapsed_time:.2f} seconds")
