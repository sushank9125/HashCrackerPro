# API Reference

## Core Classes

### ParallelEngine
```python
engine = ParallelEngine(max_workers=4, mode='process')
results = engine.parallel_crack(passwords, target_hash, algorithm)