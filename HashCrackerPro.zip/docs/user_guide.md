# HashCracker Pro - User Guide

## Table of Contents
1. [Introduction](#introduction)
2. [Installation](#installation)
3. [Quick Start](#quick-start)
4. [Command Line Interface](#command-line-interface)
5. [Interactive Mode](#interactive-mode)
6. [Attack Modes](#attack-modes)
7. [Hash Algorithms](#hash-algorithms)
8. [Performance Optimization](#performance-optimization)
9. [Advanced Features](#advanced-features)
10. [Troubleshooting](#troubleshooting)

## Introduction

HashCracker Pro is a high-performance parallel password auditing system designed for security professionals, penetration testers, and researchers. It leverages parallel computing to accelerate hash cracking operations across multiple CPU cores.

### Key Features
- 🚀 **Parallel Processing**: Utilizes multiprocessing and multithreading
- 🔐 **Multiple Hash Algorithms**: Supports MD5, SHA1, SHA256, SHA512, Bcrypt
- ⚡ **Various Attack Modes**: Dictionary, Brute Force, Hybrid, and Mask attacks
- 📊 **Real-time Progress**: Live progress tracking with statistics
- 💾 **Flexible Export**: Multiple output formats (JSON, CSV, TXT)
- 🎯 **Smart Detection**: Automatic hash type identification
- 📈 **Performance Benchmarking**: System optimization tools

## Installation

### Prerequisites
- Python 3.8 or higher
- pip (Python package manager)

### Step-by-Step Installation

1. **Clone or Download the Project**
   ```bash
   # If using git
   git clone <repository-url>
   cd HashCrackerPro
   
   # Or extract the downloaded zip file