# run.py - Working version without complex dependencies
import hashlib
import multiprocessing as mp
from concurrent.futures import ProcessPoolExecutor
import time
import os
from tqdm import tqdm

class HashCracker:
    def __init__(self, max_workers=None):
        self.max_workers = max_workers or mp.cpu_count()
    
    def identify_hash(self, hash_string):
        """Identify hash type based on length"""
        length = len(hash_string)
        if length == 32:
            return 'md5'
        elif length == 40:
            return 'sha1'
        elif length == 64:
            return 'sha256'
        elif length == 128:
            return 'sha512'
        else:
            return None
    
    def compute_hash(self, password, algorithm):
        """Compute hash of password"""
        password = password.strip()
        if algorithm == 'md5':
            return hashlib.md5(password.encode()).hexdigest()
        elif algorithm == 'sha1':
            return hashlib.sha1(password.encode()).hexdigest()
        elif algorithm == 'sha256':
            return hashlib.sha256(password.encode()).hexdigest()
        elif algorithm == 'sha512':
            return hashlib.sha512(password.encode()).hexdigest()
        else:
            return None
    
    def load_wordlist(self, file_path):
        """Load wordlist from file"""
        if not os.path.exists(file_path):
            print(f"[-] Wordlist not found: {file_path}")
            return []
        
        passwords = []
        try:
            with open(file_path, 'r', encoding='utf-8', errors='ignore') as f:
                for line in f:
                    line = line.strip()
                    if line:
                        passwords.append(line)
            return passwords
        except Exception as e:
            print(f"[-] Error loading wordlist: {e}")
            return []
    
    def crack_single_hash(self, target_hash, wordlist_path, hash_type=None, threads=4):
        """Crack a single hash"""
        banner = """
        ╔═══════════════════════════════════════════════╗
        ║              HASHCRACKER PRO                  ║
        ║        Parallel Password Auditing System      ║
        ║                                               ║
        ║           [Working Edition]                   ║
        ╚═══════════════════════════════════════════════╝
        """
        print(banner)
        
        # Auto-detect hash type
        if not hash_type:
            hash_type = self.identify_hash(target_hash)
            if not hash_type:
                print("[-] Could not identify hash type")
                return
            print(f"[*] Auto-detected: {hash_type}")
        
        print(f"[*] Target: {target_hash}")
        print(f"[*] Threads: {threads}")
        
        # Load wordlist
        passwords = self.load_wordlist(wordlist_path)
        if not passwords:
            return
        
        print(f"[*] Loaded {len(passwords)} passwords")
        print("[*] Starting attack...")
        
        start_time = time.time()
        found = False
        
        # Process in chunks for better performance
        chunk_size = max(1, len(passwords) // (threads * 2))
        
        with tqdm(total=len(passwords), desc="Cracking") as pbar:
            with ProcessPoolExecutor(max_workers=threads) as executor:
                # Split work into chunks
                futures = []
                for i in range(0, len(passwords), chunk_size):
                    chunk = passwords[i:i + chunk_size]
                    future = executor.submit(self.process_chunk, chunk, target_hash, hash_type)
                    futures.append(future)
                
                # Check results
                for future in futures:
                    result = future.result()
                    if result:
                        found = True
                        password = result
                        break
                    pbar.update(chunk_size)
        
        elapsed = time.time() - start_time
        
        if found:
            print(f"\n[+] SUCCESS! Password found in {elapsed:.2f} seconds")
            print(f"[+] Password: {password}")
            print(f"[+] Hash: {target_hash}")
        else:
            print(f"\n[-] Password not found after {elapsed:.2f} seconds")
    
    def process_chunk(self, chunk, target_hash, algorithm):
        """Process a chunk of passwords"""
        for password in chunk:
            computed_hash = self.compute_hash(password, algorithm)
            if computed_hash == target_hash:
                return password
        return None

def main():
    import argparse
    
    parser = argparse.ArgumentParser(description='HashCracker Pro - Working Edition')
    parser.add_argument('--hash', required=True, help='Hash to crack')
    parser.add_argument('--wordlist', required=True, help='Wordlist file path')
    parser.add_argument('--hash-type', help='Hash algorithm type')
    parser.add_argument('--threads', type=int, default=4, help='Number of threads')
    
    args = parser.parse_args()
    
    cracker = HashCracker()
    cracker.crack_single_hash(args.hash, args.wordlist, args.hash_type, args.threads)

if __name__ == '__main__':
    main()