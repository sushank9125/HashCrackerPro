# advanced_cracker.py - Enhanced version with more features
import hashlib
import multiprocessing as mp
from concurrent.futures import ProcessPoolExecutor
import time
import os
import argparse
from datetime import datetime

class AdvancedHashCracker:
    def __init__(self, max_workers=None):
        self.max_workers = max_workers or mp.cpu_count()
        self.results = []
        self.start_time = None
    
    def display_banner(self):
        banner = r"""
        ╔═══════════════════════════════════════════════╗
        ║              HASHCRACKER PRO                  ║
        ║        Parallel Password Auditing System      ║
        ║                                               ║
        ║           [Advanced Edition]                  ║
        ╚═══════════════════════════════════════════════╝
        """
        print(banner)
    
    def identify_hash(self, hash_string):
        length = len(hash_string)
        if length == 32:
            return 'md5'
        elif length == 40:
            return 'sha1'
        elif length == 64:
            return 'sha256'
        elif length == 128:
            return 'sha512'
        else:
            return None
    
    def compute_hash(self, password, algorithm):
        password = password.strip()
        if algorithm == 'md5':
            return hashlib.md5(password.encode()).hexdigest()
        elif algorithm == 'sha1':
            return hashlib.sha1(password.encode()).hexdigest()
        elif algorithm == 'sha256':
            return hashlib.sha256(password.encode()).hexdigest()
        elif algorithm == 'sha512':
            return hashlib.sha512(password.encode()).hexdigest()
        else:
            return None
    
    def load_wordlist(self, file_path, max_lines=None):
        if not os.path.exists(file_path):
            print(f"[-] Wordlist not found: {file_path}")
            return []
        
        passwords = []
        try:
            with open(file_path, 'r', encoding='utf-8', errors='ignore') as f:
                for line_num, line in enumerate(f, 1):
                    if max_lines and line_num > max_lines:
                        break
                    line = line.strip()
                    if line:
                        passwords.append(line)
            return passwords
        except Exception as e:
            print(f"[-] Error loading wordlist: {e}")
            return []
    
    def crack_single_hash(self, target_hash, wordlist_path, hash_type=None, threads=4):
        self.display_banner()
        
        print(f"[*] Starting attack at: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
        
        # Auto-detect hash type
        if not hash_type:
            hash_type = self.identify_hash(target_hash)
            if not hash_type:
                print("[-] Could not identify hash type")
                return
            print(f"[*] Auto-detected: {hash_type}")
        
        print(f"[*] Target hash: {target_hash}")
        print(f"[*] Using {threads} parallel workers")
        
        # Load wordlist
        print(f"[*] Loading wordlist: {wordlist_path}")
        passwords = self.load_wordlist(wordlist_path)
        if not passwords:
            print("[-] No passwords loaded!")
            return
        
        print(f"[*] Loaded {len(passwords)} passwords")
        
        self.start_time = time.time()
        found_password = None
        
        print("[*] Starting parallel cracking...")
        
        # Calculate optimal chunk size
        chunk_size = max(1, len(passwords) // (threads * 4))
        print(f"[*] Using chunk size: {chunk_size}")
        
        # Split passwords into chunks
        chunks = [passwords[i:i + chunk_size] for i in range(0, len(passwords), chunk_size)]
        
        with ProcessPoolExecutor(max_workers=threads) as executor:
            # Submit all chunks
            futures = []
            for chunk in chunks:
                future = executor.submit(self.process_chunk, chunk, target_hash, hash_type)
                futures.append(future)
            
            # Check results as they complete
            for i, future in enumerate(futures):
                result = future.result()
                if result:
                    found_password = result
                    # Cancel remaining tasks
                    for f in futures[i+1:]:
                        f.cancel()
                    break
                
                # Progress update
                progress = min((i + 1) * chunk_size, len(passwords))
                print(f"[*] Progress: {progress}/{len(passwords)} passwords tested")
        
        elapsed_time = time.time() - self.start_time
        
        if found_password:
            print(f"\n🎉 SUCCESS! Password found in {elapsed_time:.2f} seconds")
            print(f"🔑 Password: {found_password}")
            print(f"📊 Hash: {target_hash}")
            print(f"⚡ Speed: {len(passwords)/elapsed_time:.0f} passwords/second")
            
            # Save result
            self.results.append({
                'password': found_password,
                'hash': target_hash,
                'algorithm': hash_type,
                'time_taken': elapsed_time,
                'passwords_tested': len(passwords)
            })
        else:
            print(f"\n❌ Password not found after {elapsed_time:.2f} seconds")
            print(f"📊 Tested {len(passwords)} passwords")
            print(f"⚡ Speed: {len(passwords)/elapsed_time:.0f} passwords/second")
    
    def process_chunk(self, chunk, target_hash, algorithm):
        """Process a chunk of passwords"""
        for password in chunk:
            computed_hash = self.compute_hash(password, algorithm)
            if computed_hash == target_hash:
                return password
        return None
    
    def crack_multiple_hashes(self, hash_file_path, wordlist_path, threads=4):
        """Crack multiple hashes from a file"""
        self.display_banner()
        
        if not os.path.exists(hash_file_path):
            print(f"[-] Hash file not found: {hash_file_path}")
            return
        
        # Load hashes
        hashes = []
        with open(hash_file_path, 'r') as f:
            for line in f:
                line = line.strip()
                if line and not line.startswith('#'):
                    hashes.append(line)
        
        if not hashes:
            print("[-] No hashes found in file")
            return
        
        print(f"[*] Loaded {len(hashes)} hashes from {hash_file_path}")
        
        # Load wordlist
        passwords = self.load_wordlist(wordlist_path)
        if not passwords:
            return
        
        print(f"[*] Loaded {len(passwords)} passwords")
        print(f"[*] Starting batch attack with {threads} threads...")
        
        total_start = time.time()
        cracked_count = 0
        
        for i, target_hash in enumerate(hashes, 1):
            print(f"\n--- Cracking Hash {i}/{len(hashes)} ---")
            print(f"Hash: {target_hash}")
            
            hash_type = self.identify_hash(target_hash)
            if not hash_type:
                print("[-] Could not identify hash type, skipping...")
                continue
            
            start_time = time.time()
            found = False
            
            # Search for this hash
            for password in passwords:
                if self.compute_hash(password, hash_type) == target_hash:
                    elapsed = time.time() - start_time
                    print(f"🎉 CRACKED in {elapsed:.2f}s: {password}")
                    cracked_count += 1
                    found = True
                    
                    self.results.append({
                        'password': password,
                        'hash': target_hash,
                        'algorithm': hash_type,
                        'time_taken': elapsed
                    })
                    break
            
            if not found:
                print("❌ Not found")
        
        total_time = time.time() - total_start
        print(f"\n{'='*50}")
        print("📊 BATCH CRACKING COMPLETE!")
        print(f"⏱️  Total time: {total_time:.2f} seconds")
        print(f"🔑 Cracked: {cracked_count}/{len(hashes)} hashes")
        print(f"📈 Success rate: {(cracked_count/len(hashes))*100:.1f}%")
        print(f"⚡ Average speed: {len(passwords)*len(hashes)/total_time:.0f} hashes/second")
    
    def show_statistics(self):
        """Show cracking statistics"""
        if not self.results:
            print("[-] No results to show")
            return
        
        print("\n📊 CRACKING STATISTICS")
        print("=" * 30)
        print(f"Total cracked: {len(self.results)}")
        
        total_time = sum(result['time_taken'] for result in self.results)
        print(f"Total time: {total_time:.2f}s")
        
        if len(self.results) > 0:
            avg_time = total_time / len(self.results)
            print(f"Average time per hash: {avg_time:.2f}s")
        
        # Show cracked passwords
        print("\n🔑 CRACKED PASSWORDS:")
        for result in self.results:
            print(f"  {result['password']} -> {result['hash']}")

def main():
    parser = argparse.ArgumentParser(description='HashCracker Pro - Advanced Edition')
    parser.add_argument('--hash', help='Single hash to crack')
    parser.add_argument('--hash-file', help='File containing multiple hashes')
    parser.add_argument('--wordlist', required=True, help='Wordlist file path')
    parser.add_argument('--hash-type', help='Hash algorithm type')
    parser.add_argument('--threads', type=int, default=4, help='Number of threads')
    parser.add_argument('--mode', choices=['single', 'batch', 'stats'], default='single', help='Operation mode')
    
    args = parser.parse_args()
    
    cracker = AdvancedHashCracker()
    
    if args.mode == 'single' and args.hash:
        cracker.crack_single_hash(args.hash, args.wordlist, args.hash_type, args.threads)
    elif args.mode == 'batch' and args.hash_file:
        cracker.crack_multiple_hashes(args.hash_file, args.wordlist, args.threads)
    elif args.mode == 'stats':
        cracker.show_statistics()
    else:
        print("Please specify either --hash for single crack or --hash-file for batch mode")

if __name__ == '__main__':
    main()