# simple_test.py - Guaranteed to work
import hashlib

def main():
    print("=== HASHCRACKER PRO - SIMPLE TEST ===")
    
    # Test hash
    target_hash = "5f4dcc3b5aa765d61d8327deb882cf99"
    print(f"Target hash: {target_hash}")
    
    # Test passwords to try
    test_passwords = [
        "password",    # This should work
        "123456",
        "wrongpassword",
        "test"
    ]
    
    print("\nTesting passwords:")
    for pwd in test_passwords:
        computed = hashlib.md5(pwd.encode()).hexdigest()
        status = "MATCH!" if computed == target_hash else "no"
        print(f"  '{pwd}' -> {computed} -> {status}")
        
        if computed == target_hash:
            print(f"\n🎉 SUCCESS! Password is: {pwd}")
            break
    else:
        print("\n❌ Password not found in test list")

if __name__ == "__main__":
    main()